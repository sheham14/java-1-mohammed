/**
 * Java Package for Assignment 5. Creating classes for product, invoice item, and invoice.
 * Testing class for invoice checks the validation and formatting.
 * @author Sheham
 */
package ca.nl.cna.sheham.assignments.Assignment5;